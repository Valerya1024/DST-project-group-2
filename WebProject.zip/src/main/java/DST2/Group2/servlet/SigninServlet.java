package DST2.Group2.servlet;

import DST2.Group2.bean.User;
import DST2.Group2.bean.AuthenticationFilter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

import static DST2.Group2.bean.SearchUser.searchUser;

@WebServlet(name = "SigninServlet",  urlPatterns = "/signin")
public class SigninServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        User user = new User(username,password);
        boolean b = searchUser(user)[1];
        System.out.println(b);
        if (b) {
            HttpSession session = request.getSession();
            session.setAttribute(AuthenticationFilter.ROLE_VIEW_DOSING_GUIDELINE, 1);
            session.setAttribute(AuthenticationFilter.USERNAME, username);
            response.sendRedirect("index");
        } else {
            request.setAttribute("error", "username or password error");
            request.getRequestDispatcher("/WEB-INF/view/signin.jsp").forward(request, response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/view/signin.jsp").forward(request, response);
    }
}
