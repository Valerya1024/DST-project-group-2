package DST2.Group2.servlet;
import DST2.Group2.bean.User;
import DST2.Group2.bean.AuthenticationFilter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

import static DST2.Group2.bean.RegisterUser.InsertUser;
import static DST2.Group2.bean.SearchUser.searchUser;

@WebServlet(name = "RegisterServlet",  urlPatterns = "/register")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        System.out.println(username + "\n" + password);
        User user = new User(username, password);
        if (searchUser(user)[0] == false) {
            System.out.println("1");
            try {
                InsertUser(user);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            response.sendRedirect("signin");
        } else {
            System.out.println("2");
            request.setAttribute("error", "username has already been taken");
            request.getRequestDispatcher("/views/register.jsp").forward(request, response);
        }
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/view/register.jsp").forward(request, response);
    }
}
