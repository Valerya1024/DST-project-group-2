# DST-project-group-2

Run release (current v2.8)
1. clone/download repository
2. create PostgreSQL database with name 'biomed'.
3. create tables in PostgreSQL database by running codes in /src/main/resources/Table_creation.sql
4. config /src/main/resources/app.properties by filling the username and password of the database you have created.
5. to set up the database, run method initSystem() in src/test/java/basic/UpdateDataTest.java; this should only be operated once.
6. default administrator is username: zju; password: zju.

Annotation result
1. HepG2_ann.hg38_multianno.txt
2. HepG2.vcf

We are:
Jeff Gui: Email: Yifan.18@intl.zju.edu.cn

Jixin Wang Email: Jixin.18@intl.zju.edu.cn

Yuxing Zhou Email: Yuxing.18@intl.zju.edu.cn

Caiylyn Jiang Email: Anlan.18@intl.zju.edu.cn

Valerya Wu Email: Xinyu.18@intl.zju.edu.cn
